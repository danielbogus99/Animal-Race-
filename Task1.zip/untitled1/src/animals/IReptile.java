package animals;

public interface IReptile
{
   public static final int Max_SPEED = 5;
   public void speedUp(int speed);
}

package Graphics;
public interface IClonable  extends Cloneable
{

}

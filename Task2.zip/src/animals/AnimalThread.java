package animals;

public class AnimalThread implements Runnable {
    private Animal participant;
    private double neededDistance;
    private Boolean startFlag;
    private Boolean finishFlag;



    @Override
    public void run()
    {

    }
}

package Graphics;

public interface IMoveable
{
    public String getAnimalName();
    public int getSpeed();
    public double move();

}
